"""
preprocessing for spark,sklearn,tensorflow,torch
"""
