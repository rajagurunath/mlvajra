from pre_sklearn import Tabular

Tabular.add_dummy_feature
Tabular.FunctionTransformer()
Tabular.add_dummy_feature