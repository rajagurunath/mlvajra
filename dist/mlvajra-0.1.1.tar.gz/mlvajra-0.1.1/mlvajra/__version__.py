"""A Last weapon to save Data scientist"""
__version__='0.1'
